import json
import unittest

class test(unittest.TestCase):
    def test_0(self):
        assert 'ACTIVE' == 'ACTIVE'